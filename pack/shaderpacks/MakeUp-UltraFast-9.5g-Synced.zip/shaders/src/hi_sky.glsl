#ifdef UNKNOWN_DIM
    vec3 ZenithSkyColorRGB = skyColor;
    zenithSkyColor = rgbToXyz(ZenithSkyColorRGB);
#else
    vec3 ZenithSkyColorRGB = dayBlend(
        ZENITH_SUNSET_COLOR,
        mix(ZENITH_DAY_COLOR, PW_CLEAR_ZENITH_DAY, photon_clear_sky()), // synced weather: bluer on clear days
        ZENITH_NIGHT_COLOR
    );

    ZenithSkyColorRGB = mix(
        ZenithSkyColorRGB,
        ZENITH_SKY_RAIN_COLOR * luma(ZenithSkyColorRGB),
        rainStrength
    );

    zenithSkyColor = rgbToXyz(ZenithSkyColorRGB);
#endif
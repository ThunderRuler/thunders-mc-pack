#if MC_VERSION >= 11300
    // SYNCED/PHOTON WEATHER: coverage follows Photon's world-time weather instead of a fixed value.
    // Photon coverage 0.10 (clear) .. 0.65 (overcast)  ->  MakeUp threshold 0.62 (fair-weather puffs) .. 0.20 (near-solid).
    umbral = mix(0.62, 0.20, smoothstep(0.10, 0.68, photon_cloud_coverage(rainStrength)));
    umbral = mix(umbral, 0.25, smoothstep(0.0, 1.0, rainStrength)); // rain: full cover, as stock MakeUp
#else
    umbral = (smoothstep(1.0, 0.0, rainStrength) * .3) + .55;
#endif

darkCloudColor = dayBlend(
    ZENITH_SUNSET_COLOR,
    ZENITH_DAY_COLOR,
    ZENITH_NIGHT_COLOR
);

darkCloudColor = mix(
    darkCloudColor,
    ZENITH_SKY_RAIN_COLOR * colorAverage(darkCloudColor),
    rainStrength
);

vec3 cloudColor_aux = mix(
    dayBlend(
        LIGHT_SUNSET_COLOR,
        LIGHT_DAY_COLOR,
        LIGHT_NIGHT_COLOR * vec3(0.5, 0.6, 0.75)
    ),
    ZENITH_SKY_RAIN_COLOR * colorAverage(darkCloudColor),
    rainStrength
);

cloudColor = mix(
    clamp(mix(vec3(luma(cloudColor_aux)), cloudColor_aux, 0.5) * vec3(1.5), 0.0, 1.4),
    dayBlend(
        HORIZON_SUNSET_COLOR,
        HORIZON_DAY_COLOR,
        HORIZON_NIGHT_COLOR
    ),
    0.3
);

cloudColor = mix(cloudColor, HORIZON_SKY_RAIN_COLOR * luma(cloudColor_aux) * 5.0, rainStrength);

darkCloudColor = mix(darkCloudColor, cloudColor, 0.22);

darkCloudColor = mix(
    darkCloudColor,
    dayBlend(
        cloudColor_aux,
        darkCloudColor,
        darkCloudColor
    ),
    0.4
);
#ifndef PHOTON_WEATHER_INCLUDED
#define PHOTON_WEATHER_INCLUDED
/* PHOTON-STYLE WEATHER (local edit for a friends' modpack)
   Port of Photon 1.3b's weather model (include/weather/core.glsl + clouds_l0_coverage in weather/clouds.glsl):
   temperature, humidity and wind drift slowly with WORLD time, which the server sends to every player,
   so cloud coverage changes over time in the same way for everyone, and roughly when Photon's does.
   Biome influence is left out (Photon's biome uniforms don't exist here). Runs per vertex: no measurable cost. */

uniform float cloud_world_time; // ((worldDay % 128) * 24000 + worldTime) / 20, see shaders.properties

float pw_hash1(float p) {
    p = fract(p * .1031);
    p *= p + 33.33;
    p *= p + p;
    return fract(p);
}

float pw_noise_1d(float x) {
    float i = floor(x);
    float f = x - i;
    f = f * f * (3.0 - 2.0 * f);
    return mix(pw_hash1(i), pw_hash1(i + 1.0), f);
}

float pw_linear_step(float e0, float e1, float x) { return clamp((x - e0) / (e1 - e0), 0.0, 1.0); }
float pw_dampen(float x) { x = clamp(x, 0.0, 1.0); return x * (2.0 - x); }

// Photon's l0 (cumulus) coverage, about 0.1 (clear) to 0.65 (overcast) in dry weather.
float photon_cloud_coverage(float rain) {
    const float golden_ratio = 1.618034;
    float t = cloud_world_time;

    // Time of day from world time (approximates Photon's sun-direction weights).
    float tod = mod(t * 20.0, 24000.0);
    float time_midnight = clamp(1.0 - abs(tod - 18000.0) / 6000.0, 0.0, 1.0);
    float time_sunrise = clamp(1.0 - min(abs(tod - 23500.0), tod + 500.0) / 2000.0, 0.0, 1.0);

    float temperature = pw_noise_1d(t * (0.37 * golden_ratio / 600.0) + 2.5);
    temperature = clamp(temperature - 0.2 * time_sunrise - 0.2 * time_midnight, 0.0, 1.0);
    float humidity = clamp(mix(0.2, 0.8, pw_noise_1d(t * (0.37 * golden_ratio / 600.0) + 46.618)) + rain, 0.0, 1.0);
    float wind = clamp(pw_noise_1d(t * (0.5 * golden_ratio / 600.0) + 83.236) + 0.33 * rain, 0.0, 1.0);

    float stratus = clamp(pw_dampen(pw_linear_step(0.5, 1.0, 1.0 - temperature)) * pw_dampen(1.0 - wind), 0.0, 1.0);
    float temperature_weight = 1.0 - 0.15 * pw_linear_step(0.6, 1.0, temperature);
    float humidity_weight = 0.4 * humidity + 0.5 * humidity * humidity;
    float local_variation = -0.1 * (0.1 + 0.1 * wind);

    return clamp(temperature_weight * humidity_weight + local_variation + 0.3 * stratus * stratus, 0.0, 1.0);
}

// Clear-sky factor for the sky colour: 1 on Photon's clear days, 0 when overcast.
float photon_clear_sky() { return 1.0 - smoothstep(0.15, 0.55, photon_cloud_coverage(0.0)); }
#define PW_CLEAR_ZENITH_DAY vec3(0.10, 0.25, 0.58)
#define PW_CLEAR_HORIZON_DAY vec3(0.55, 0.78, 1.15)

#endif